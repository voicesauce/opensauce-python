opensauce-python
================
A Python port of Voicesauce/OpenSauce. A set of command-line tools for taking automatic voice measurements from audio records.

# Installation

# Quickstart

# Resources
* documentation: someday
* [https://github.com/voicesauce/opensauce](OpenSauce)
* [http://www.seas.ucla.edu/spapl/voicesauce/](VoiceSauce)


