#!/bin/bash

indir="defaults/sounds"
outdir="defaults/output"

python runner $indir $outdir

echo "Success!"