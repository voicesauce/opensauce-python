__author__ = 'kate'


def start():
    print "starting..."
